package com.landmarkgroup.api.returnpolicyenquiry.configuration;

import org.kie.api.KieServices;
import org.kie.api.builder.*;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.context.annotation.Bean;

//@Configuration
class DroolsConfiguration {

    @Bean
    public KieSession kieContainer() {
        KieServices kieServices = KieServices.Factory.get();

        ReleaseId releaseId = kieServices.newReleaseId("com.drools.example", "kjar-example", "2.0.0-SNAPSHOT");
        KieContainer kieContainer =  kieServices.newKieContainer(releaseId);
        KieScanner kieScanner = kieServices.newKieScanner(kieContainer);
        kieScanner.start(2000);
        return kieContainer.newKieSession("session1");
    }

//    @Bean
//    @KContainer
//    @KReleaseId(groupId = "com.drools.example", artifactId = "kjar-example", version = "2.0.0-SNAPSHOT")
//    public KieContainer kieContainer() {
//        return KieServices.Factory.get().getKieClasspathContainer();
//
//        }

}