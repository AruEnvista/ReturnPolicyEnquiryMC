package com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class ExternalOrderRequest {
    @NonNull
    private String customer_order_id;

    @NonNull
    private String enterprise_code;

    private String status;

    @NonNull
    private String source;

    private boolean is_legacy_order=false;

    private boolean is_manager_override=false;

    private List<ExternalOrderLines> order_lines;
}


